//
//  ViewController.swift
//  BMI_ljh
//
//  Created by LimJongHoon on 11/13/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

